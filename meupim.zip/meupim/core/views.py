from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    return HttpResponse("Eu sou a Index")

def detalhe(request, id):
    return HttpResponse(f"Eu sou o detalhe {id}")
# Create your views here.
