from django.contrib import admin
from .models import Uf
from .models import Cidade
from .models import Servico
from .models import Atestados
from .models import Colaboradores
from .models import Farmácia
from .models import Relatório
from .models import Prontuário
from .models import Agendamento
from .models import Atendimento


admin.site.register(Uf)
admin.site.register(Cidade)
admin.site.register(Servico)
admin.site.register(Atestados)
admin.site.register(Colaboradores)
admin.site.register(Farmácia)
admin.site.register(Relatório)
admin.site.register(Prontuário)
admin.site.register(Agendamento)
admin.site.register(Atendimento)    