from django.db import models

# Create your models here.
class Uf(models.Model):
   sigla = models.CharField(max_length=2)
   nome = models.CharField(max_length=15)

   def __str__(self):
       return self.nome


class Cidade(models.Model):
   uf = models.ForeignKey(Uf, on_delete=models.CASCADE,
                             related_name='cidades')
   nome = models.CharField(max_length=15)

   def __str__(self):
       return self.nome
   
class Servico(models.Model):
    nome = models.CharField(max_length=100)
    descricao = models.TextField()
    preco = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
       return self.descricao

class Atestados(models.Model):
    idAtestado = models.CharField(max_length=100)
    horarioExame = models.DateTimeField()
    tipoAtestado = models.CharField(max_length=100)
    cidAtestado = models.CharField(max_length=100)
    diasAtestado = models.TimeField()
    resultadoExame = models.CharField(max_length=100)
    id_ColaboradorImpressao = models.CharField(max_length=100)

    def __str__(self):
       return self.descricao
    
class Colaboradores(models.Model):
    idColaborador = models.CharField(max_length=100)
    pontoHorario = models.DateTimeField()
    cpfColaborador = models.CharField(max_length=100)
    nomeColaborador = models.CharField(max_length=100)
    dataNascimento = models.DateField()
    especialidade = models.CharField(max_length=100)
    telefoneColaborador = models.CharField(max_length=100)
    enderecoColaborador = models.CharField(max_length=100)
    escalaTurno = models.CharField(max_length=100)

    def __str__(self):
       return self.descricao
    
class Farmácia(models.Model):
    receituarioPaciente = models.CharField(max_length=100)
    nomeRemedio = models.CharField(max_length=100)
    tipoRemedio = models.CharField(max_length=100)
    fabricanteRemedio = models.CharField(max_length=100)
    formaPagamento = models.CharField(max_length=100)
    preco = models.DecimalField(max_digits=10, decimal_places=2)
    
    def __str__(self):
       return self.descricao
    
class Relatório(models.Model):
    cpfPaciente = models.CharField(max_length=100)
    dataVisita = models.DateField()
    motivoVisita = models.CharField(max_length=300)
    sintomasRegistrados = models.CharField(max_length=300)
    remediosRecomendados = models.CharField(max_length=200)
    tratamentos = models.CharField(max_length=200)

    def __str__(self):
       return self.descricao
    
class Prontuário(models.Model):
    cpfPaciente = models.CharField(max_length=100)
    nomePaciente = models.CharField(max_length=100)
    dataProximaVisita = models.DateField()
    dataVisita = models.DateField()
    motivoVisita = models.CharField(max_length=300)
    medicoResponsavel = models.CharField(max_length=300)
    remediosRepassados = models.CharField(max_length=200)
    tratamentoRealizado = models.CharField(max_length=200)

    def __str__(self):
       return self.descricao
    
class Agendamento(models.Model):
    cpfPaciente = models.CharField(max_length=100)
    nomePaciente = models.CharField(max_length=100)
    data = models.DateField()
    motivoAgendamento = models.CharField(max_length=300)
    localAtendimento = models.CharField(max_length=100)
    formaPagamento = models.CharField(max_length=100)
    confirmacaoPagamento = models.CharField(max_length=100)
    convenio = models.CharField(max_length=100)
    medicoDia = models.CharField(max_length=100)

    def __str__(self):
       return self.descricao

class Atendimento(models.Model):
    cpfPaciente = models.CharField(max_length=100)
    confirmacaoPagamento = models.CharField(max_length=100)
    senhaAtendimento = models.CharField(max_length=100)
    historicoConsulta = models.CharField(max_length=200)
    senhasChamadas = models.CharField(max_length=100)

    def __str__(self):
       return self.descricao