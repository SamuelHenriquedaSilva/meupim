# venv

> ambiente virtual para uso isolado de bibliotecas do Python, ou seja, as bibliotecas instaladas não estarão no escopo global do sistema operacional.

1 - Crie uma pasta chamada projeto (ex: no Desktop)
2 - Abra no VS code
3 - Abra o Terminal do VS Code

4 - Criação da venv
```
python -m venv venv

PS: venv\Scripts\Activate

```
> Provalvente primeira execução no Power Shell retornará erro de Política de Segurança, caso isso ocorra, digite o comando abaixo:

```
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope CurrentUser
```

```
PS: venv\Scripts\Activate
```

- O comando acima funcionando, retornará o nome da venv que foi criada entre parenteses, algo parecido com:

(venv) ...

# Instalar o Django

```
(venv) pip install django
```

# Criar projeto Django

```
(venv) django-admin startproject meupim
```

(venv) ....projeto>cd meupim
(venv) ....meupim>dir
(venv) ....meupim>python manage.py runserver

Abra o seguinte endereço no navegador:
127.0.0.1:8000 

> Para parar o servidor basta utilizar CTRL+C


```
python manage.py runserver
```


# Criar app

```
python manage.py startapp core
```

INSTALLED_APPS
	'' 
	'static',
	'core'

Aproveite o arquivo settings.py aberto e já altere o valor de LANGUAGE_CODE = 'pt-br'

# models.py

```python
from django.db import models


# Create your models here.
class Uf(models.Model):
   sigla = models.CharField(max_length=2)
   nome = models.CharField(max_length=15)

   def __str__(self):
       return self.nome


class Cidade(models.Model):
   uf = models.ForeignKey(Uf, on_delete=models.CASCADE,
                             related_name='cidades')
   nome = models.CharField(max_length=15)

   def __str__(self):
       return self.nome
```

python manage.py makemigrations

python manage.py migrate 


# Client SQL

# Django shell

# admin.py

```python
from django.contrib import admin
from .models import Uf


# Register your models here.
admin.site.register(Uf)
admin.site.register(Cidade)
```

# Superuser

python manage.py createsuperuser
user: admin
password: admin

(yes/No): yes

python manage.py runserver

http://127.0.0.1:8000/admin

> Autenticar com admin/ admin criado anteriormente